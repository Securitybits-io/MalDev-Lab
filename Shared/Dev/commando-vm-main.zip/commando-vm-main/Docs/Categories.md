# Categories
The following is the current list of supported categories for CommandoVM.
These will serve as the Folders used to organize 
tools in the user's Desktop\Tools\ directory.

- Command & Control
- Credential Access
- Exploitation
- Lateral Movement
- Payload Development
- Persistence
- Privilege Escalation
- Reconnaissance
- Utilities
- Wordlists