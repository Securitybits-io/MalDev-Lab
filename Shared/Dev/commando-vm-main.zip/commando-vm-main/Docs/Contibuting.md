## Contributing
Want to get started contributing? See the links below to learn how.

### Installer
* [Commando VM installation script, GUI, and configuration](https://github.com/mandiant/commando-vm)

### Tool Packages
* [Repository of all tool packages (VM-packages)](https://github.com/mandiant/VM-Packages)
* [Documentation and contribution guides for tool packages](https://github.com/mandiant/VM-Packages/wiki)
* [Submit new tool packages or report package related issues](https://github.com/mandiant/VM-Packages/issues)